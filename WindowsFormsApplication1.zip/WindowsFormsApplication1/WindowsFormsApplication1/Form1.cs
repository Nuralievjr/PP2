﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Graphics g;
        bool ClickedMouse;
        Point prev, cur;
        Pen pen;
        public enum Tool
        {
            PEN,
            RECTANGLE
        };
        Tool tool;
        public Form1()
        {
            InitializeComponent();
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.Image = bmp;
            g = Graphics.FromImage(bmp);
            pen = new Pen(Color.Black);
            ClickedMouse = false;
            tool = Tool.PEN;
        }

       

        

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {

            if(tool == Tool.RECTANGLE)
            {
               
                int x = Math.Min(prev.X, cur.X);
                int y = Math.Min(prev.Y, cur.Y);
                int w = Math.Abs(prev.X - cur.X);
                int h = Math.Abs(prev.Y - cur.Y);
                g.DrawRectangle(pen, x, y,w, h);
            }
            pictureBox1.Refresh();
            ClickedMouse = false;
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            ClickedMouse = true;
            prev = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            cur = e.Location;
            if (ClickedMouse)
            {
                if (tool == Tool.PEN)
                {
                    g.DrawLine(pen, prev,cur);
                    prev = cur;
                }
                pictureBox1.Refresh();
            }
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (tool == Tool.RECTANGLE && ClickedMouse == true)
            {
                int x = Math.Min(prev.X, cur.X);
                int y = Math.Min(prev.Y, cur.Y);
                int w = Math.Abs(prev.X - cur.X);
                int h = Math.Abs(prev.Y - cur.Y);
                e.Graphics.DrawRectangle(pen, x, y, w, h);


            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            tool = Tool.RECTANGLE;
        }

        private void PEN_Click(object sender, EventArgs e)
        {
            tool = Tool.PEN;
            
        }
    }
}
